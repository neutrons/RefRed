#-*- coding: utf-8 -*-
'''
This will keep record of all the metadata previously selected
'''

import os
config_path = os.path.expanduser('~/tmp/path_config')

metadata_list = ['']
