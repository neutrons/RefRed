#-*- coding: utf-8 -*-
'''
This will keep record of all the last config, ascii and reduced files
'''

import os
config_path = os.path.expanduser('~/tmp/path_config')

reduce1 = ''
date1 = ''
reduce2 = ''
date2 = ''
reduce3 = ''
date3 = ''
reduce4 = ''
date4 = ''
reduce5 = ''
date5 = ''
reduce6 = ''
date6 = ''
reduce7 = ''
date7 = ''
reduce8 = ''
date8 = ''
reduce9 = ''
date9 = ''
reduce10 = ''
date10 = ''

config_files_path = ''
