class ExportStitchingAsciiSettings(object):
	
	fourth_column_flag = True
	fourth_column_dq0 = 0.0004
	fourth_column_dq_over_q = 0.023
	use_lowest_error_value_flag = True
	
	
	