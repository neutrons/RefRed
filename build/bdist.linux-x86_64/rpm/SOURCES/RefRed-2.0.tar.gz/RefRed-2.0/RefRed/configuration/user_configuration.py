class UserConfiguration(object):

    is_reduced_plot_stitching_tab_ylog = True
    is_reduced_plot_stitching_tab_xlog = False
    
    def __init__(self):
        pass
    
