#-*- coding: utf-8 -*-

# the minor version and change date gets automatically updated on a git commit
window_title = 'Liquids Reflectometer Reduction - '

version = (2, 0)
last_changes = ""
str_version = ".".join(map(str, version))
