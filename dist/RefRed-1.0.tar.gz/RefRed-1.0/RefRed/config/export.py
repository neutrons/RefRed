#-*- coding: utf-8 -*-
'''
Options specific to the data file export in qio.
'''

config_file='reduction'

exportSpecular=True
exportTrueSpecular=False
exportOffSpecular=False
exportOffSpecularCorr=False
exportOffSpecularSmoothed=False
exportGISANS=False

sampleSize=10.

emailSend=False
multiAscii=True
combinedAscii=False
matlab=False
mantidplot=True
gnuplot=False
numpy=False
plot=True
genx=False
