#-*- coding: utf-8 -*-
'''
Options for the matplotlib graph creation.
'''

config_file='gui'

font={
      'family' : 'serif',
      #  'weight' : 'normal',
      #  'variant': 'DejaVuSerif',
        'size': 7,
        }
savefig={
         'dpi': 600,
         }
